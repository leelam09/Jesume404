import ResumetoInterviewBlog from '@/component/Blog/Blog5'
import React from 'react'

const page = () => {
  return (
    <div>
<div><ResumetoInterviewBlog/></div>

    </div>
  )
}

export default page