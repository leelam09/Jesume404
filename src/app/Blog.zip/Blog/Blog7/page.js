import RecruiterAIResumeInsights from '@/component/Blog/Blog7'
import React from 'react'

const page = () => {
  return (
    <div>

<div><RecruiterAIResumeInsights/></div>


    </div>
  )
}

export default page