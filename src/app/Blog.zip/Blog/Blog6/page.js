import AIFriendlyResumeBlog from '@/component/Blog/Blog6'
import React from 'react'

const page = () => {
  return (
    <div>
<div><AIFriendlyResumeBlog/></div>

    </div>
  )
}

export default page