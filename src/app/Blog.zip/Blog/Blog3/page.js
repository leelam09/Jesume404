import AIToolsBlog from '@/component/Blog/Blog3'
import React from 'react'

const page = () => {
  return (
    <div>
<div><AIToolsBlog/></div>

    </div>
  )
}

export default page