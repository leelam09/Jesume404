import AIImproveBlog from '@/component/Blog/Blog4'
import React from 'react'

const page = () => {
  return (
    <div>
<div><AIImproveBlog/></div>

    </div>
  )
}

export default page