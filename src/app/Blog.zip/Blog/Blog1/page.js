import AIResumeBlogRedesign from '@/component/Blog/Blog1'
import React from 'react'

const page = () => {
  return (
    <div>

<div><AIResumeBlogRedesign/></div>

    </div>
  )
}

export default page