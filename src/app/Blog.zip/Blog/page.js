import React from 'react'
import BlogMain from '@/component/Blog/BlogMain'

const page = () => {
  return (
    <div>

      <div><BlogMain/></div>
    </div>
  )
}

export default page