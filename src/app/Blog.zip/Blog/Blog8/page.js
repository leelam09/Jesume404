import CoverLetterVsResume from '@/component/Blog/Blog8'
import React from 'react'

const page = () => {
  return (
    <div>
<div><CoverLetterVsResume/></div>


    </div>
  )
}

export default page